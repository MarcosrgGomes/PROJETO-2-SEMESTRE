<?php
/**
 * Serenity - Sistema de Gerenciamento de Estoque
 * Sprint 1 - Foco em Frontend com Backend Simulado
 * 
 * Arquivo principal de entrada do sistema
 */

// Definir constantes do sistema
define('BASE_PATH', __DIR__);
define('APP_PATH', BASE_PATH . '/app');
define('DATA_PATH', BASE_PATH . '/data');
define('PUBLIC_PATH', BASE_PATH . '/public');

// Incluir arquivos de configuração (antes de session_start)
require_once APP_PATH . '/config/config.php';

// Iniciar sessão (após as configurações)
session_start();

// Incluir helpers e segurança
require_once APP_PATH . '/config/helpers.php';
require_once APP_PATH . '/config/security.php';

// Inicializar sistema de dados
DataManager::init();

// Roteamento simples
$page = isset($_GET['page']) ? $_GET['page'] : 'login';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

// Verificar autenticação (exceto para páginas públicas)
$publicPages = ['login', 'register', 'forgot-password', 'reset-password'];
if (!in_array($page, $publicPages) && !isLoggedIn()) {
    header('Location: index.php?page=login');
    exit;
}

// Roteamento de controladores
switch ($page) {
    case 'login':
    case 'register':
    case 'forgot-password':
    case 'reset-password':
    case 'logout':
        require_once APP_PATH . '/controllers/AuthController.php';
        $controller = new AuthController();
        break;
    
    case 'dashboard':
        require_once APP_PATH . '/controllers/DashboardController.php';
        $controller = new DashboardController();
        break;
    
    case 'products':
        require_once APP_PATH . '/controllers/ProductController.php';
        $controller = new ProductController();
        break;
    
    case 'suppliers':
        require_once APP_PATH . '/controllers/SupplierController.php';
        $controller = new SupplierController();
        break;
    
    case 'stock':
        require_once APP_PATH . '/controllers/StockController.php';
        $controller = new StockController();
        break;
    
    case 'users':
        require_once APP_PATH . '/controllers/UserController.php';
        $controller = new UserController();
        break;
    
    case 'categories':
        require_once APP_PATH . '/controllers/CategoryController.php';
        $controller = new CategoryController();
        break;
    
    default:
        require_once APP_PATH . '/views/errors/404.php';
        exit;
}

// Executar ação do controlador
if (method_exists($controller, $action)) {
    $controller->$action();
} else {
    $controller->index();
}

