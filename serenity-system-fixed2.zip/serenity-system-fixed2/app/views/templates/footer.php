    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section about">
                <h4>Sobre Nós</h4>
                <p>Serenity é um sistema de gerenciamento de estoque focado em simplicidade e eficiência para pequenas e médias empresas.</p>
            </div>
            <div class="footer-section contact">
                <h4>Contato</h4>
                <ul>
                    <li><i class="fas fa-map-marker-alt"></i> Rua Exemplo, 99 - Santo André, São Paulo</li>
                    <li><i class="fas fa-phone"></i> (XX) XXXX-XXXX</li>
                    <li><i class="fas fa-envelope"></i> contato@serenity.com</li>
                </ul>
            </div>
            <div class="footer-section social">
                <h4>Redes Sociais</h4>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> Serenity. Todos os direitos reservados.
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="public/js/app.js"></script>
    <!-- FontAwesome para ícones sociais -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>

