<?php
$pageTitle = 'Editar Produto';
require_once APP_PATH . '/views/templates/header.php';
?>

<div class="app-container">
    <?php require_once APP_PATH . '/views/templates/navigation.php'; ?>
    
    <main class="main-content">
        <header class="topbar">
            <div class="topbar-left">
                <h1 class="topbar-title">Editar Produto</h1>
            </div>
            <div class="topbar-right">
                <a href="index.php?page=products" class="btn btn-secondary">
                    ← Voltar
                </a>
                <div class="user-menu">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr(getCurrentUser()['name'], 0, 1)); ?>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="content-area">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Editar: <?php echo $product['name']; ?></h3>
                </div>
                <div class="card-body">
                    <form action="index.php?page=products&action=update" method="POST" data-validate>
                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                        <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-6);">
                            <div class="form-group">
                                <label for="sku" class="form-label">SKU</label>
                                <input 
                                    type="text" 
                                    id="sku" 
                                    name="sku" 
                                    class="form-control" 
                                    value="<?php echo $product['sku']; ?>"
                                    readonly
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="name" class="form-label required">Nome do Produto</label>
                                <input 
                                    type="text" 
                                    id="name" 
                                    name="name" 
                                    class="form-control" 
                                    value="<?php echo $product['name']; ?>"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="category" class="form-label required">Categoria</label>
                                <select id="category" name="category" class="form-control" required>
                                    <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['name']; ?>" <?php echo $product['category'] === $cat['name'] ? 'selected' : ''; ?>>
                                        <?php echo $cat['name']; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="cost_price" class="form-label required">Preço de Custo</label>
                                <input 
                                    type="number" 
                                    id="cost_price" 
                                    name="cost_price" 
                                    class="form-control" 
                                    value="<?php echo $product['cost_price']; ?>"
                                    step="0.01"
                                    min="0"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="sale_price" class="form-label required">Preço de Venda</label>
                                <input 
                                    type="number" 
                                    id="sale_price" 
                                    name="sale_price" 
                                    class="form-control" 
                                    value="<?php echo $product['sale_price']; ?>"
                                    step="0.01"
                                    min="0"
                                    required
                                >
                                <small class="form-text">
                                    Markup: <span id="markup_display" style="font-weight: 700;">
                                        <?php echo number_format(calculateMarkup($product['cost_price'], $product['sale_price']), 2); ?>%
                                    </span>
                                </small>
                            </div>
                            
                            <div class="form-group">
                                <label for="quantity" class="form-label required">Quantidade</label>
                                <input 
                                    type="number" 
                                    id="quantity" 
                                    name="quantity" 
                                    class="form-control" 
                                    value="<?php echo $product['quantity']; ?>"
                                    min="0"
                                    required
                                >
                                <small class="form-text">Use "Movimentações" para ajustes com histórico</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="min_quantity" class="form-label required">Quantidade Mínima</label>
                                <input 
                                    type="number" 
                                    id="min_quantity" 
                                    name="min_quantity" 
                                    class="form-control" 
                                    value="<?php echo $product['min_quantity']; ?>"
                                    min="0"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label for="status" class="form-label required">Status</label>
                                <select id="status" name="status" class="form-control" required>
                                    <?php foreach (PRODUCT_STATUS as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" <?php echo $product['status'] === $key ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="description" class="form-label">Descrição</label>
                            <textarea 
                                id="description" 
                                name="description" 
                                class="form-control" 
                                rows="4"
                            ><?php echo $product['description']; ?></textarea>
                        </div>
                        
                        <div style="display: flex; gap: var(--space-3); justify-content: flex-end; margin-top: var(--space-8);">
                            <a href="index.php?page=products" class="btn btn-secondary">
                                Cancelar
                            </a>
                            <button type="submit" class="btn btn-success">
                                💾 Salvar Alterações
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<?php require_once APP_PATH . '/views/templates/footer.php'; ?>

